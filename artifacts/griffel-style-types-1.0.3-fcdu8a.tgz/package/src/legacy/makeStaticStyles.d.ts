import type * as CSS from 'csstype';
export type GriffelStaticStyle = {
    [key: string]: CSS.Properties & Record<string, any>;
} & {
    '@font-face'?: {
        fontFamily: string;
        src: string;
        fontFeatureSettings?: string;
        fontStretch?: string;
        fontStyle?: string;
        fontVariant?: string;
        fontVariationSettings?: string;
        fontWeight?: number | string;
        unicodeRange?: string;
    };
};
export type GriffelStaticStyles = GriffelStaticStyle | string;
