import type { JSONSchema7 } from 'json-schema';
export declare const optionsSchema: JSONSchema7;
