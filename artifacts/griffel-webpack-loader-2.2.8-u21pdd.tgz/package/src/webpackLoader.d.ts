import type { BabelPluginOptions } from '@griffel/babel-preset';
import type * as webpack from 'webpack';
export type WebpackLoaderOptions = BabelPluginOptions & {
    inheritResolveOptions?: ('alias' | 'modules' | 'plugins' | 'conditionNames' | 'extensions')[];
    webpackResolveOptions?: Pick<Required<webpack.Configuration>['resolve'], 'alias' | 'modules' | 'plugins' | 'conditionNames' | 'extensions'>;
};
type WebpackLoaderParams = Parameters<webpack.LoaderDefinitionFunction<WebpackLoaderOptions>>;
export declare function shouldTransformSourceCode(sourceCode: string, modules: WebpackLoaderOptions['modules'] | undefined): boolean;
export declare function webpackLoader(this: webpack.LoaderContext<WebpackLoaderOptions>, sourceCode: WebpackLoaderParams[0], inputSourceMap: WebpackLoaderParams[1]): void;
export {};
