"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.optionsSchema = void 0;
const babel_preset_1 = require("@griffel/babel-preset");
exports.optionsSchema = {
    ...babel_preset_1.configSchema,
    properties: {
        ...babel_preset_1.configSchema.properties,
        inheritResolveOptions: {
            type: 'array',
            items: { type: 'string', enum: ['alias', 'modules', 'plugins', 'conditionNames', 'extensions'] },
        },
        webpackResolveOptions: {
            type: 'object',
            properties: {
                alias: {
                    oneOf: [
                        {
                            type: 'object',
                            properties: {
                                alias: { oneOf: [{ type: 'string' }, { enum: [false] }, { type: 'array', items: { type: 'string' } }] },
                                name: { type: 'string' },
                                onlyModule: { type: 'boolean' },
                            },
                            required: ['alias', 'name'],
                        },
                        {
                            type: 'object',
                            patternProperties: {
                                ['.*']: {
                                    oneOf: [{ type: 'string' }, { enum: [false] }, { type: 'array', items: { type: 'string' } }],
                                },
                            },
                        },
                    ],
                },
                conditionNames: { type: 'array', items: { type: 'string' } },
                extensions: { type: 'array', items: { type: 'string' } },
                modules: { type: 'array', items: { type: 'string' } },
                plugins: {
                    oneOf: [
                        { type: 'string', enum: ['...'] },
                        { type: 'object', additionalProperties: true },
                    ],
                },
            },
        },
    },
};
//# sourceMappingURL=schema.js.map