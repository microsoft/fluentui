import type { GriffelRenderer } from '@griffel/core';
import { Compilation } from 'webpack';
import type { Compiler } from 'webpack';
type EntryPoint = Compilation['entrypoints'] extends Map<unknown, infer I> ? I : never;
export type GriffelCSSExtractionPluginOptions = {
    compareMediaQueries?: GriffelRenderer['compareMediaQueries'];
    /** Specifies if the CSS extracted from Griffel calls should be attached to a specific chunk with an entrypoint. */
    unstable_attachToEntryPoint?: string | ((chunk: EntryPoint) => boolean);
};
export declare class GriffelCSSExtractionPlugin {
    static loader: string;
    private readonly attachToEntryPoint;
    private readonly compareMediaQueries;
    constructor(options?: GriffelCSSExtractionPluginOptions);
    apply(compiler: Compiler): void;
}
export {};
