import type { GriffelRenderer, CSSRulesByBucket } from '@griffel/core';
export declare function sortCSSRules(setOfCSSRules: CSSRulesByBucket[], compareMediaQueries: GriffelRenderer['compareMediaQueries']): string;
