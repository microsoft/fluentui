import type * as webpack from 'webpack';
import type { SupplementedLoaderContext } from './constants';
export type WebpackLoaderOptions = {
    /**
     * Please never use this feature, it will be removed without further notice.
     */
    unstable_keepOriginalCode?: boolean;
};
type WebpackLoaderParams = Parameters<webpack.LoaderDefinitionFunction<WebpackLoaderOptions>>;
declare function webpackLoader(this: SupplementedLoaderContext<WebpackLoaderOptions>, sourceCode: WebpackLoaderParams[0], inputSourceMap: WebpackLoaderParams[1]): void;
export default webpackLoader;
