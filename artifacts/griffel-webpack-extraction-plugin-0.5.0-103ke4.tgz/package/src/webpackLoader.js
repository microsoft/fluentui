"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@griffel/core");
const path = require("path");
const transformSync_1 = require("./transformSync");
const constants_1 = require("./constants");
const virtualLoaderPath = path.resolve(__dirname, '..', 'virtual-loader', 'index.js');
const virtualCSSFilePath = path.resolve(__dirname, '..', 'virtual-loader', 'griffel.css');
/**
 * Webpack can also pass sourcemaps as a string or null, Babel accepts only objects, boolean and undefined.
 * See https://github.com/babel/babel-loader/pull/889.
 */
function parseSourceMap(inputSourceMap) {
    try {
        if (typeof inputSourceMap === 'string') {
            return JSON.parse(inputSourceMap);
        }
        if (inputSourceMap === null) {
            return undefined;
        }
        return inputSourceMap;
    }
    catch (err) {
        return undefined;
    }
}
function toURIComponent(rule) {
    return encodeURIComponent(rule).replace(/!/g, '%21');
}
function webpackLoader(sourceCode, inputSourceMap) {
    var _a;
    this.async();
    // Loaders are cacheable by default, but in edge cases/bugs when caching does not work until it's specified:
    // https://github.com/webpack/webpack/issues/14946
    this.cacheable();
    // Early return to handle cases when __styles() calls are not present, allows skipping expensive invocation of Babel
    if (sourceCode.indexOf('__styles') === -1 && sourceCode.indexOf('__resetStyles') === -1) {
        this.callback(null, sourceCode, inputSourceMap);
        return;
    }
    const IS_RSPACK = !this.webpack;
    // @ Rspack compat:
    // We don't use the trick with loader context as assets are generated differently
    if (!IS_RSPACK) {
        if (!this[constants_1.GriffelCssLoaderContextKey]) {
            throw new Error('GriffelCSSExtractionPlugin is not configured, please check your webpack config');
        }
    }
    const { unstable_keepOriginalCode } = this.getOptions();
    let result = null;
    let error = null;
    try {
        result = (0, transformSync_1.transformSync)(sourceCode, {
            filename: path.relative(process.cwd(), this.resourcePath),
            enableSourceMaps: this.sourceMap || false,
            inputSourceMap: parseSourceMap(inputSourceMap),
        });
    }
    catch (err) {
        error = err;
    }
    if (result) {
        const resultCode = unstable_keepOriginalCode ? sourceCode : result.code;
        const resultSourceMap = unstable_keepOriginalCode ? inputSourceMap : result.sourceMap;
        const { cssRulesByBucket } = result;
        if (cssRulesByBucket) {
            const entries = Object.entries(cssRulesByBucket);
            if (entries.length === 0) {
                this.callback(null, resultCode, resultSourceMap);
                return;
            }
            // TODO: make this smarter
            const css = entries.reduce((acc, [cssBucketName, cssBucketRules]) => {
                return (acc +
                    cssBucketRules
                        .map(entry => {
                        return [
                            `/** @griffel:css-start [${cssBucketName}] [${JSON.stringify(entry[1])}] **/`,
                            (0, core_1.normalizeCSSBucketEntry)(entry)[0],
                            `/** @griffel:css-end **/`,
                            '',
                        ].join('\n');
                    })
                        .join(''));
            }, '');
            if (IS_RSPACK) {
                const request = `griffel.css!=!${virtualLoaderPath}!${virtualCSSFilePath}?style=${toURIComponent(css)}`;
                const stringifiedRequest = JSON.stringify(this.utils.contextify(this.context || this.rootContext, request));
                this.callback(null, `${resultCode}\n\nimport ${stringifiedRequest};`, resultSourceMap);
                return;
            }
            (_a = this[constants_1.GriffelCssLoaderContextKey]) === null || _a === void 0 ? void 0 : _a.registerExtractedCss(css);
            const outputFileName = this.resourcePath.replace(/\.[^.]+$/, '.griffel.css');
            const request = `${outputFileName}!=!${virtualLoaderPath}!${this.resourcePath}`;
            const stringifiedRequest = JSON.stringify(this.utils.contextify(this.context || this.rootContext, request));
            this.callback(null, `${resultCode}\n\nimport ${stringifiedRequest};`, resultSourceMap);
            return;
        }
        this.callback(null, resultCode, resultSourceMap);
        return;
    }
    this.callback(error);
}
exports.default = webpackLoader;
//# sourceMappingURL=webpackLoader.js.map