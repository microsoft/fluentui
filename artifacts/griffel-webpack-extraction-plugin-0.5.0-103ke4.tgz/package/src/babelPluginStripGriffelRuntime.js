"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.babelPluginStripGriffelRuntime = void 0;
const core_1 = require("@babel/core");
const helper_module_imports_1 = require("@babel/helper-module-imports");
const helper_plugin_utils_1 = require("@babel/helper-plugin-utils");
function concatCSSRulesByBucket(bucketA = {}, bucketB) {
    Object.entries(bucketB).forEach(([cssBucketName, cssBucketEntries]) => {
        bucketA[cssBucketName] = cssBucketEntries.concat(bucketA[cssBucketName] || []);
    });
    return bucketA;
}
function evaluateAndUpdateArgument(argumentPath, functionKind, state) {
    // Returns the styles as a JavaScript object
    const evaluationResult = argumentPath.evaluate();
    if (!evaluationResult.confident) {
        throw argumentPath.buildCodeFrameError([
            `Failed to evaluate CSS rules from "${functionKind}" call.`,
            'Please report a bug (https://github.com/microsoft/griffel/issues) if this error happens',
        ].join(' '));
    }
    if (functionKind === '__styles') {
        const cssRulesByBucket = evaluationResult.value;
        state.cssRulesByBucket = concatCSSRulesByBucket(state.cssRulesByBucket, cssRulesByBucket);
    }
    else if (functionKind === '__resetStyles') {
        const cssRules = evaluationResult.value;
        state.cssRulesByBucket = concatCSSRulesByBucket(state.cssRulesByBucket, Array.isArray(cssRules) ? { r: cssRules } : cssRules);
    }
    argumentPath.remove();
}
function getFunctionArgumentPath(callExpressionPath, functionKind) {
    const argumentPaths = callExpressionPath.get('arguments');
    if (functionKind === '__styles') {
        if (argumentPaths.length === 2 && argumentPaths[1].isObjectExpression()) {
            return argumentPaths[1];
        }
    }
    if (functionKind === '__resetStyles') {
        if (argumentPaths.length === 3 && (argumentPaths[2].isArrayExpression() || argumentPaths[2].isObjectExpression())) {
            return argumentPaths[2];
        }
    }
    return null;
}
function getReferencePaths(specifierPath, functionKind) {
    const importedPath = specifierPath.get('imported');
    if (importedPath.isIdentifier({ name: functionKind })) {
        const localPath = specifierPath.get('local');
        const programPath = specifierPath.findParent(p => p.isProgram());
        const importBinding = programPath.scope.getBinding(localPath.node.name);
        if (importBinding) {
            return importBinding.referencePaths;
        }
    }
    return [];
}
function inlineAssetImports(argumentPath) {
    const importsToRemove = new Set();
    argumentPath.traverse({
        TemplateLiteral(literalPath) {
            const expressionPaths = literalPath.get('expressions');
            expressionPaths.map(expressionPath => {
                if (Array.isArray(expressionPath) || !expressionPath.isIdentifier()) {
                    throw literalPath.buildCodeFrameError([
                        'A template literal with an imported asset should contain an expression statement.',
                        'Please report a bug (https://github.com/microsoft/griffel/issues) if this error happens',
                    ].join(' '));
                }
                const expressionName = expressionPath.node.name;
                const expressionBinding = literalPath.scope.getBinding(expressionName);
                if (typeof expressionBinding === 'undefined') {
                    throw expressionPath.buildCodeFrameError([
                        'Failed to resolve a binding in a scope for an identifier.',
                        'Please report a bug (https://github.com/microsoft/griffel/issues) if this error happens',
                    ].join(' '));
                }
                const importDeclarationPath = expressionBinding.path.findParent(p => p.isImportDeclaration());
                if (importDeclarationPath === null) {
                    throw expressionBinding.path.buildCodeFrameError([
                        'Failed to resolve an import for the identifier.',
                        'Please report a bug (https://github.com/microsoft/griffel/issues) if this error happens',
                    ].join(' '));
                }
                expressionPath.replaceWith(core_1.types.stringLiteral(importDeclarationPath.get('source').node.value));
                importsToRemove.add(importDeclarationPath);
            });
        },
    });
    // It's unsafe to remove imports in the middle of a traversal as imports can be reused between CSS rules
    importsToRemove.forEach(importDeclarationPath => {
        importDeclarationPath.remove();
    });
}
function updateCalleeName(callExpressionPath, importName) {
    const calleePath = callExpressionPath.get('callee');
    calleePath.replaceWith(core_1.types.identifier(importName));
}
function updateReferences(state, importSpecifierPath, importSource, functionKind) {
    var _a;
    const importName = functionKind === '__styles' ? '__css' : '__resetCSS';
    const importIdentifier = (0, helper_module_imports_1.addNamed)(importSpecifierPath, importName, importSource);
    const referencePaths = getReferencePaths(importSpecifierPath, functionKind);
    for (const referencePath of referencePaths) {
        if ((_a = referencePath.parentPath) === null || _a === void 0 ? void 0 : _a.isCallExpression()) {
            const callExpressionPath = referencePath.parentPath;
            const argumentPath = getFunctionArgumentPath(callExpressionPath, functionKind);
            if (argumentPath) {
                inlineAssetImports(argumentPath);
                evaluateAndUpdateArgument(argumentPath, functionKind, state);
                updateCalleeName(callExpressionPath, importIdentifier.name);
            }
        }
    }
}
exports.babelPluginStripGriffelRuntime = (0, helper_plugin_utils_1.declare)(api => {
    api.assertVersion(7);
    return {
        name: '@griffel/webpack-extraction-plugin/babel',
        post() {
            this.file.metadata.cssRulesByBucket = this.cssRulesByBucket;
        },
        visitor: {
            Program: {
                enter(path, state) {
                    if (typeof state.filename === 'undefined') {
                        throw new Error([
                            '@griffel/webpack-extraction-plugin: This plugin requires "filename" option to be specified by Babel. ',
                            "It's automatically done by our loaders. ",
                            "If you're facing this issue, please check your setup.\n\n",
                            'See: https://babeljs.io/docs/en/options#filename',
                        ].join(''));
                    }
                },
                exit(path, state) {
                    path.traverse({
                        ImportSpecifier(path) {
                            const importedPath = path.get('imported');
                            const importSourcePath = path.parentPath.get('source');
                            const importSource = importSourcePath.node.value;
                            if (importedPath.isIdentifier({ name: '__styles' })) {
                                updateReferences(state, path, importSource, '__styles');
                            }
                            else if (importedPath.isIdentifier({ name: '__resetStyles' })) {
                                updateReferences(state, path, importSource, '__resetStyles');
                            }
                        },
                    });
                },
            },
        },
    };
});
//# sourceMappingURL=babelPluginStripGriffelRuntime.js.map