"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GriffelCssLoaderContextKey = exports.PLUGIN_NAME = void 0;
exports.PLUGIN_NAME = 'GriffelExtractPlugin';
exports.GriffelCssLoaderContextKey = Symbol(`${exports.PLUGIN_NAME}/GriffelCssLoaderContextKey`);
//# sourceMappingURL=constants.js.map