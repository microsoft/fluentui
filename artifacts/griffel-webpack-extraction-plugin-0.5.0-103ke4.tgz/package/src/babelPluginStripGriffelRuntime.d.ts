import type { PluginObj, PluginPass } from '@babel/core';
import type { CSSRulesByBucket } from '@griffel/core';
type StripRuntimeBabelPluginOptions = Record<string, unknown>;
type StripRuntimeBabelPluginState = PluginPass & {
    cssRulesByBucket?: CSSRulesByBucket;
};
export type StripRuntimeBabelPluginMetadata = {
    cssRulesByBucket?: CSSRulesByBucket;
};
export declare const babelPluginStripGriffelRuntime: (api: object, options: Partial<StripRuntimeBabelPluginOptions> | null | undefined, dirname: string) => PluginObj<StripRuntimeBabelPluginState>;
export {};
