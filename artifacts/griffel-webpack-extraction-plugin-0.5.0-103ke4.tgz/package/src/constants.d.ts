import type { LoaderContext } from 'webpack';
export declare const PLUGIN_NAME = "GriffelExtractPlugin";
export declare const GriffelCssLoaderContextKey: unique symbol;
export interface GriffelLoaderContextSupplement {
    registerExtractedCss(css: string): void;
    getExtractedCss(): string;
}
export type SupplementedLoaderContext<Options = unknown> = LoaderContext<Options> & {
    [GriffelCssLoaderContextKey]?: GriffelLoaderContextSupplement;
};
