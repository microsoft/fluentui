"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sortCSSRules = void 0;
const core_1 = require("@griffel/core");
function getCSSRuleFromBucketEntry(entry) {
    return Array.isArray(entry) ? entry[0] : entry;
}
function getCSSMetaFromBucketEntry(entry) {
    return Array.isArray(entry) ? entry[1] : {};
}
function getRulePriority(entry) {
    var _a;
    return (_a = getCSSMetaFromBucketEntry(entry)['p']) !== null && _a !== void 0 ? _a : 0;
}
function sortCSSRules(setOfCSSRules, compareMediaQueries) {
    return core_1.styleBucketOrdering
        .map(styleBucketName => {
        return {
            styleBucketName,
            cssBucketEntries: 
            // We deduplicate CSS rules there by using them as keys in an object:
            // - create an array with pairs [key, value]
            // - use Object.fromEntries() to create an object that contains unique values
            Object.values(Object.fromEntries(setOfCSSRules.flatMap(cssRulesByBucket => {
                if (Array.isArray(cssRulesByBucket[styleBucketName])) {
                    return cssRulesByBucket[styleBucketName].map(bucketEntry => [
                        getCSSRuleFromBucketEntry(bucketEntry),
                        bucketEntry,
                    ]);
                }
                return [];
            }))),
        };
    })
        .reduce((acc, { styleBucketName, cssBucketEntries }) => {
        if (styleBucketName === 'm') {
            return (acc +
                cssBucketEntries
                    .sort((entryA, entryB) => {
                    return compareMediaQueries(getCSSMetaFromBucketEntry(entryA)['m'], getCSSMetaFromBucketEntry(entryB)['m']);
                })
                    .map(entry => entry[0])
                    .join(''));
        }
        return (acc +
            cssBucketEntries
                .sort((entryA, entryB) => {
                return getRulePriority(entryA) - getRulePriority(entryB);
            })
                .map(entry => getCSSRuleFromBucketEntry(entry))
                .join(''));
    }, '');
}
exports.sortCSSRules = sortCSSRules;
//# sourceMappingURL=sortCSSRules.js.map