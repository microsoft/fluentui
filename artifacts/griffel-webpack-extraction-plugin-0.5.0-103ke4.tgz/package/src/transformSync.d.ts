import * as Babel from '@babel/core';
import type { CSSRulesByBucket } from '@griffel/core';
export type TransformOptions = {
    filename: string;
    inputSourceMap: Babel.TransformOptions['inputSourceMap'];
    enableSourceMaps: boolean;
};
export type TransformResult = {
    code: string;
    cssRulesByBucket: CSSRulesByBucket | undefined;
    sourceMap: NonNullable<Babel.BabelFileResult['map']> | undefined;
};
/**
 * Transforms passed source code with Babel, uses user's config for parsing, but ignores it for transforms.
 */
export declare function transformSync(sourceCode: string, options: TransformOptions): TransformResult;
