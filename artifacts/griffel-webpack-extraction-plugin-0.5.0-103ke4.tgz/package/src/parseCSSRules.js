"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseCSSRules = void 0;
const core_1 = require("@griffel/core");
const stylis_1 = require("stylis");
function parseCSSRules(css) {
    const cssRulesByBucket = core_1.styleBucketOrdering.reduce((acc, styleBucketName) => {
        acc[styleBucketName] = [];
        return acc;
    }, {});
    const elements = (0, stylis_1.compile)(css);
    const unrelatedElements = [];
    let cssBucketName = null;
    let cssMeta = null;
    for (const element of elements) {
        if (element.type === stylis_1.COMMENT) {
            if (element.value.indexOf('/** @griffel:css-start') === 0) {
                cssBucketName = element.value.charAt(24);
                if (element.value.charAt(27) === '[') {
                    cssMeta = JSON.parse(element.value.slice(28, -5));
                }
                continue;
            }
            if (element.value.indexOf('/** @griffel:css-end') === 0) {
                cssBucketName = null;
                cssMeta = null;
                continue;
            }
        }
        if (cssBucketName) {
            const cssRule = (0, stylis_1.serialize)([element], stylis_1.stringify);
            const bucketEntry = cssMeta ? [cssRule, cssMeta] : cssRule;
            cssRulesByBucket[cssBucketName].push(bucketEntry);
            continue;
        }
        unrelatedElements.push(element);
    }
    return { cssRulesByBucket, remainingCSS: (0, stylis_1.serialize)(unrelatedElements, stylis_1.stringify) };
}
exports.parseCSSRules = parseCSSRules;
//# sourceMappingURL=parseCSSRules.js.map