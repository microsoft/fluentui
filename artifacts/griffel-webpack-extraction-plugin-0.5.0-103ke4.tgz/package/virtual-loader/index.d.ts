export = virtualLoader;
/**
 * @this {import("../src/constants").SupplementedLoaderContext}
 * @return {String}
 */
declare function virtualLoader(this: import("../src/constants").SupplementedLoaderContext<unknown>): string;
