import { DEBUG_RESET_CLASSES } from './constants.esm.js';
import { insertionFactory } from './insertionFactory.esm.js';
import { resolveResetStyleRules } from './runtime/resolveResetStyleRules.esm.js';

function makeResetStyles(styles, factory = insertionFactory) {
  const insertStyles = factory();
  let ltrClassName = null;
  let rtlClassName = null;
  let cssRules = null;
  function computeClassName(options) {
    const {
      dir,
      renderer
    } = options;
    if (ltrClassName === null) {
      [ltrClassName, rtlClassName, cssRules] = resolveResetStyleRules(styles);
    }
    insertStyles(renderer, Array.isArray(cssRules) ? {
      r: cssRules
    } : cssRules);
    const className = dir === 'ltr' ? ltrClassName : rtlClassName || ltrClassName;
    if (process.env.NODE_ENV !== 'production') {
      DEBUG_RESET_CLASSES[className] = 1;
    }
    return className;
  }
  return computeClassName;
}

export { makeResetStyles };
//# sourceMappingURL=makeResetStyles.esm.js.map
