import { DATA_BUCKET_ATTR } from '../constants.esm.js';
import { createIsomorphicStyleSheet } from './createIsomorphicStyleSheet.esm.js';

/**
 * Ordered style buckets using their short pseudo name.
 *
 * @internal
 */
const styleBucketOrdering = [
// reset styles
'r',
// catch-all
'd',
// link
'l',
// visited
'v',
// focus-within
'w',
// focus
'f',
// focus-visible
'i',
// hover
'h',
// active
'a',
// at rules for reset styles
's',
// keyframes
'k',
// at-rules
't',
// @media rules
'm',
// @container rules
'c'];

// avoid repeatedly calling `indexOf`to determine order during new insertions
const styleBucketOrderingMap = /*#__PURE__*/styleBucketOrdering.reduce((acc, cur, j) => {
  acc[cur] = j;
  return acc;
}, {});

/**
 * Lazily adds a `<style>` bucket to the `<head>`. This will ensure that the style buckets are ordered.
 */
function getStyleSheetForBucket(bucketName, targetDocument, insertionPoint, renderer, metadata = {}) {
  const isMediaBucket = bucketName === 'm';
  const priority = metadata['p'];
  const stylesheetKey = (isMediaBucket ? bucketName + metadata['m'] : bucketName) + (priority != null ? priority : '');
  if (!renderer.stylesheets[stylesheetKey]) {
    const tag = targetDocument && targetDocument.createElement('style');
    const stylesheet = createIsomorphicStyleSheet(tag, bucketName, Object.assign({}, renderer.styleElementAttributes, isMediaBucket && {
      media: metadata['m']
    }), priority);
    renderer.stylesheets[stylesheetKey] = stylesheet;
    if (targetDocument && tag) {
      targetDocument.head.insertBefore(tag, findInsertionPoint(targetDocument, insertionPoint, bucketName, renderer, metadata));
    }
  }
  return renderer.stylesheets[stylesheetKey];
}
function isTheSameKey(element, bucketName, metadata) {
  var _ref, _element$media;
  const targetKey = bucketName + ((_ref = metadata['m']) != null ? _ref : '');
  const elementKey = element.getAttribute(DATA_BUCKET_ATTR) + ((_element$media = element.media) != null ? _element$media : '');
  return targetKey === elementKey;
}

/**
 * Finds an element before which the new bucket style element should be inserted following the bucket sort order.
 *
 * @param targetDocument - A document
 * @param insertionPoint - An element that will be used as an initial insertion point
 * @param targetBucket - The bucket that should be inserted to DOM
 * @param renderer - Griffel renderer
 * @param metadata - metadata for CSS rule
 * @returns - Smallest style element with greater sort order than the current bucket
 */
function findInsertionPoint(targetDocument, insertionPoint, targetBucket, renderer, metadata) {
  var _ref2;
  const targetOrder = styleBucketOrderingMap[targetBucket];
  const priority = (_ref2 = metadata == null ? void 0 : metadata['p']) != null ? _ref2 : 0;

  // Similar to javascript sort comparators where
  // a positive value is increasing sort order
  // a negative value is decreasing sort order
  let comparer = el => targetOrder - styleBucketOrderingMap[el.getAttribute(DATA_BUCKET_ATTR)];
  const priorityComparer = el => {
    var _el$getAttribute;
    const elPriority = Number((_el$getAttribute = el.getAttribute('data-priority')) != null ? _el$getAttribute : 0);
    return priority - elPriority;
  };
  let styleElements = targetDocument.head.querySelectorAll(`[${DATA_BUCKET_ATTR}]`);
  if (targetBucket === 'm' && metadata) {
    const mediaElements = targetDocument.head.querySelectorAll(`[${DATA_BUCKET_ATTR}="${targetBucket}"]`);

    // only reduce the scope of the search and change comparer
    // if there are other media buckets already on the page
    if (mediaElements.length) {
      styleElements = mediaElements;
      comparer = el => renderer.compareMediaQueries(metadata['m'], el.media);
    }
  }
  const length = styleElements.length;
  let index = length - 1;
  while (index >= 0) {
    const styleElement = styleElements.item(index);
    if (isTheSameKey(styleElement, targetBucket, metadata != null ? metadata : {})) {
      if (priorityComparer(styleElement) > 0) {
        return styleElement.nextSibling;
      }
    }
    if (comparer(styleElement) > 0) {
      return styleElement.nextSibling;
    }
    index--;
  }
  if (length > 0) {
    return styleElements.item(0);
  }
  return insertionPoint ? insertionPoint.nextSibling : null;
}

export { getStyleSheetForBucket, styleBucketOrdering };
//# sourceMappingURL=getStyleSheetForBucket.esm.js.map
