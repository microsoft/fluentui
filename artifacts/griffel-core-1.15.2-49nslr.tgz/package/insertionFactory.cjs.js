'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

/**
 * Default implementation of insertion factory. Inserts styles only once per renderer and performs
 * insertion immediately after styles computation.
 *
 * @internal
 */
const insertionFactory = () => {
  const insertionCache = {};
  return function insertStyles(renderer, cssRules) {
    if (insertionCache[renderer.id] === undefined) {
      renderer.insertCSSRules(cssRules);
      insertionCache[renderer.id] = true;
    }
  };
};

exports.insertionFactory = insertionFactory;
//# sourceMappingURL=insertionFactory.cjs.js.map
