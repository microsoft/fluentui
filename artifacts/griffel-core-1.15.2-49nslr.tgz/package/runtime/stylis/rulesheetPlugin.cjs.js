'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

/**
 * The same plugin as in stylis, but this version also has "element" argument.
 */
function rulesheetPlugin(callback) {
  return function (element) {
    if (!element.root) {
      if (element.return) {
        callback(element, element.return);
      }
    }
  };
}

exports.rulesheetPlugin = rulesheetPlugin;
//# sourceMappingURL=rulesheetPlugin.cjs.js.map
