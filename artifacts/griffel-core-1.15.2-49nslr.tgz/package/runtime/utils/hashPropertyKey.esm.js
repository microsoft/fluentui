import hashString from '@emotion/hash';

function hashPropertyKey(selector, container, media, support, property) {
  // uniq key based on property & selector, used for merging later
  const computedKey = selector + container + media + support + property;

  // "key" can be really long as it includes selectors, we use hashes to reduce sizes of keys
  // ".foo :hover" => "abcd"
  const hashedKey = hashString(computedKey);

  // As these hashes are used as object keys in build output we should avoid having numbers as a first character to
  // avoid having quotes:
  // {
  //   "1abc": {}, // we don't want this
  //   Aabc: {}, // no quotes
  // }
  const firstCharCode = hashedKey.charCodeAt(0);
  const startsWithNumber = firstCharCode >= 48 && firstCharCode <= 57;
  if (startsWithNumber) {
    return String.fromCharCode(firstCharCode + 17) + hashedKey.slice(1);
  }
  return hashedKey;
}

export { hashPropertyKey };
//# sourceMappingURL=hashPropertyKey.esm.js.map
