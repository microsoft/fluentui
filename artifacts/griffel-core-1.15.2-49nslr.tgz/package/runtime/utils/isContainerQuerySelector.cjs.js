'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function isContainerQuerySelector(property) {
  return property.substring(0, 10) === '@container';
}

exports.isContainerQuerySelector = isContainerQuerySelector;
//# sourceMappingURL=isContainerQuerySelector.cjs.js.map
