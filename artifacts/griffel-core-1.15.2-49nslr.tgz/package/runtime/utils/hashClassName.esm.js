import hashString from '@emotion/hash';
import { HASH_PREFIX } from '../../constants.esm.js';

function hashClassName({
  container,
  media,
  layer,
  property,
  selector,
  support,
  value
}) {
  const classNameHash = hashString(selector + container + media + layer + support + property +
  // Trimming of value is required to generate consistent hashes
  value.trim());
  return HASH_PREFIX + classNameHash;
}

export { hashClassName };
//# sourceMappingURL=hashClassName.esm.js.map
