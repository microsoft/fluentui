const isDevToolsEnabled = /*#__PURE__*/(() => {
  // Accessing "window.sessionStorage" causes an exception when third party cookies are blocked
  // https://stackoverflow.com/questions/30481516/iframe-in-chrome-error-failed-to-read-localstorage-from-window-access-deni
  try {
    var _window$sessionStorag;
    return Boolean(typeof window !== 'undefined' && ((_window$sessionStorag = window.sessionStorage) == null ? void 0 : _window$sessionStorag.getItem('__GRIFFEL_DEVTOOLS__')));
  } catch (e) {
    return false;
  }
})();

export { isDevToolsEnabled };
//# sourceMappingURL=isDevToolsEnabled.esm.js.map
