import type { CSSClassesMapBySlot, CSSRulesByBucket, GriffelInsertionFactory } from './types';
import type { MakeStylesOptions } from './makeStyles';
/**
 * A version of makeStyles() that accepts build output as an input and skips all runtime transforms.
 *
 * @internal
 */
export declare function __styles<Slots extends string>(classesMapBySlot: CSSClassesMapBySlot<Slots>, cssRules: CSSRulesByBucket, factory?: GriffelInsertionFactory): (options: Pick<MakeStylesOptions, 'dir' | 'renderer'>) => Record<Slots, string>;
