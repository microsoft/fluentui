import type { GriffelStyle } from '@griffel/style-types';
import type { MarginInput } from './types';
type MarginStyle = Pick<GriffelStyle, 'marginTop' | 'marginRight' | 'marginBottom' | 'marginLeft'>;
export declare function margin(all: MarginInput): MarginStyle;
export declare function margin(vertical: MarginInput, horizontal: MarginInput): MarginStyle;
export declare function margin(top: MarginInput, horizontal: MarginInput, bottom: MarginInput): MarginStyle;
export declare function margin(top: MarginInput, right: MarginInput, bottom: MarginInput, left: MarginInput): MarginStyle;
export {};
