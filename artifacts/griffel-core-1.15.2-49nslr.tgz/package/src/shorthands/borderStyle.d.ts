import type { GriffelStyle } from '@griffel/style-types';
import type { BorderStyleInput } from './types';
type BorderStyleStyle = Pick<GriffelStyle, 'borderTopStyle' | 'borderRightStyle' | 'borderBottomStyle' | 'borderLeftStyle'>;
export declare function borderStyle(all: BorderStyleInput): BorderStyleStyle;
export declare function borderStyle(vertical: BorderStyleInput, horizontal: BorderStyleInput): BorderStyleStyle;
export declare function borderStyle(top: BorderStyleInput, horizontal: BorderStyleInput, bottom: BorderStyleInput): BorderStyleStyle;
export declare function borderStyle(top: BorderStyleInput, right: BorderStyleInput, bottom: BorderStyleInput, left: BorderStyleInput): BorderStyleStyle;
export {};
