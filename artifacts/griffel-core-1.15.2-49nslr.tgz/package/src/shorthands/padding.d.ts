import type { GriffelStyle } from '@griffel/style-types';
import type { PaddingInput } from './types';
type PaddingStyle = Pick<GriffelStyle, 'paddingTop' | 'paddingRight' | 'paddingBottom' | 'paddingLeft'>;
export declare function padding(all: PaddingInput): PaddingStyle;
export declare function padding(vertical: PaddingInput, horizontal: PaddingInput): PaddingStyle;
export declare function padding(top: PaddingInput, horizontal: PaddingInput, bottom: PaddingInput): PaddingStyle;
export declare function padding(top: PaddingInput, right: PaddingInput, bottom: PaddingInput, left: PaddingInput): PaddingStyle;
export {};
