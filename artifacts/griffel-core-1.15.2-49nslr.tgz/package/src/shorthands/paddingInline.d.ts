import type { GriffelStyle } from '@griffel/style-types';
import type { PaddingInlineInput } from './types';
type PaddingInlineStyle = Pick<GriffelStyle, 'paddingInlineStart' | 'paddingInlineEnd'> | Pick<GriffelStyle, 'paddingInline'>;
/**
 * A function that implements CSS spec conformant expansion for "padding-inline"
 *
 * @deprecated Just use the "paddingInline" property directly, TODO link
 *
 * @example
 *   paddingInline('10px')
 *   paddingInline('10px', '5px')
 *
 * See https://developer.mozilla.org/en-US/docs/Web/CSS/padding-inline
 */
export declare function paddingInline(start: PaddingInlineInput, end?: PaddingInlineInput): PaddingInlineStyle;
export {};
