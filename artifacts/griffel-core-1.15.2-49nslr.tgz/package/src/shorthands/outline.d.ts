import type { GriffelStyle } from '@griffel/style-types';
import type { OutlineColorInput, OutlineStyleInput, OutlineWidthInput } from './types';
type OutlineStyle = Pick<GriffelStyle, 'outlineColor' | 'outlineStyle' | 'outlineWidth'> | Pick<GriffelStyle, 'outline'>;
export declare function outline(width: OutlineWidthInput): OutlineStyle;
export declare function outline(width: OutlineWidthInput, style: OutlineStyleInput): OutlineStyle;
export declare function outline(width: OutlineWidthInput, style: OutlineStyleInput, color: OutlineColorInput): OutlineStyle;
export {};
