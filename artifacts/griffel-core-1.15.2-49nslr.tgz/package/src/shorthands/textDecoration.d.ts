import type { GriffelStyle } from '@griffel/style-types';
import type { TextDecorationColorInput, TextDecorationLineInput, TextDecorationStyleInput, TextDecorationThicknessInput } from './types';
type TextDecorationStyle = Pick<GriffelStyle, 'textDecorationStyle' | 'textDecorationLine' | 'textDecorationColor' | 'textDecorationThickness'>;
export declare function textDecoration(style: TextDecorationStyleInput): TextDecorationStyle;
export declare function textDecoration(line: TextDecorationLineInput): TextDecorationStyle;
export declare function textDecoration(line: TextDecorationLineInput, style: TextDecorationStyleInput): TextDecorationStyle;
export declare function textDecoration(line: TextDecorationLineInput, style: TextDecorationStyleInput, color: TextDecorationColorInput): TextDecorationStyle;
export declare function textDecoration(line: TextDecorationLineInput, style: TextDecorationStyleInput, color: TextDecorationColorInput, thickness: TextDecorationThicknessInput): TextDecorationStyle;
export {};
