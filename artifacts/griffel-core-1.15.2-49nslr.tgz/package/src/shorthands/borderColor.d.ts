import type { GriffelStyle } from '@griffel/style-types';
import type { BorderColorInput } from './types';
type BorderColorStyle = Pick<GriffelStyle, 'borderTopColor' | 'borderRightColor' | 'borderBottomColor' | 'borderLeftColor'>;
export declare function borderColor(all: BorderColorInput): BorderColorStyle;
export declare function borderColor(vertical: BorderColorInput, horizontal: BorderColorInput): BorderColorStyle;
export declare function borderColor(top: BorderColorInput, horizontal: BorderColorInput, bottom: BorderColorInput): BorderColorStyle;
export declare function borderColor(top: BorderColorInput, right: BorderColorInput, bottom: BorderColorInput, left: BorderColorInput): BorderColorStyle;
export {};
