import type { GriffelStyle } from '@griffel/style-types';
import type { FlexInput } from './types';
type FlexStyle = Pick<GriffelStyle, 'flexGrow' | 'flexShrink' | 'flexBasis'> | Pick<GriffelStyle, 'flex'>;
/**
 * A function that implements CSS spec conformant expansion for "flex".
 *
 * @deprecated Use the "flex" property directly, TODO link
 *
 * @example
 *   flex('auto')
 *   flex(1, '2.5rem')
 *   flex(0, 0, 'auto')
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/CSS/flex
 */
export declare function flex(...values: FlexInput): FlexStyle;
export {};
