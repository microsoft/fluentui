import type { GriffelStyle } from '@griffel/style-types';
import type { MarginBlockInput } from './types';
type MarginBlockStyle = Pick<GriffelStyle, 'marginBlockStart' | 'marginBlockEnd'> | Pick<GriffelStyle, 'marginBlock'>;
/**
 * A function that implements CSS spec conformant expansion for "margin-block"
 *
 * @deprecated Use the "marginBlock" property directly, TODO link
 *
 * @example
 *   marginBlock('10px')
 *   marginBlock('10px', '5px')
 *
 * See https://developer.mozilla.org/en-US/docs/Web/CSS/margin-block
 */
export declare function marginBlock(start: MarginBlockInput, end?: MarginBlockInput): MarginBlockStyle;
export {};
