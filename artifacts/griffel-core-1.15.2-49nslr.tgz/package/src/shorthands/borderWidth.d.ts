import type { GriffelStyle } from '@griffel/style-types';
import type { BorderWidthInput } from './types';
type BorderWidthStyle = Pick<GriffelStyle, 'borderTopStyle' | 'borderRightStyle' | 'borderBottomStyle' | 'borderLeftStyle'>;
export declare function borderWidth(all: BorderWidthInput): BorderWidthStyle;
export declare function borderWidth(vertical: BorderWidthInput, horizontal: BorderWidthInput): BorderWidthStyle;
export declare function borderWidth(top: BorderWidthInput, horizontal: BorderWidthInput, bottom: BorderWidthInput): BorderWidthStyle;
export declare function borderWidth(top: BorderWidthInput, right: BorderWidthInput, bottom: BorderWidthInput, left: BorderWidthInput): BorderWidthStyle;
export {};
