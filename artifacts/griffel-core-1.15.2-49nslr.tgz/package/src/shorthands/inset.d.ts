import type { GriffelStyle } from '@griffel/style-types';
import type { InsetInput } from './types';
type InsetStyle = Pick<GriffelStyle, 'top' | 'right' | 'bottom' | 'left'> | Pick<GriffelStyle, 'inset'>;
export declare function inset(all: InsetInput): InsetStyle;
export declare function inset(vertical: InsetInput, horizontal: InsetInput): InsetStyle;
export declare function inset(top: InsetInput, horizontal: InsetInput, bottom: InsetInput): InsetStyle;
export declare function inset(top: InsetInput, right: InsetInput, bottom: InsetInput, left: InsetInput): InsetStyle;
export {};
