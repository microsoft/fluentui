import type { GriffelStyle } from '@griffel/style-types';
import type { GridAreaInput } from './types';
type GridAreaStyle = Pick<GriffelStyle, 'gridRowStart' | 'gridRowEnd' | 'gridColumnStart' | 'gridColumnEnd'>;
export declare function isCustomIdent(value: GridAreaInput | undefined): boolean;
export declare function gridArea(all: GridAreaInput): GridAreaStyle;
export declare function gridArea(rowStart: GridAreaInput, columnStart: GridAreaInput): GridAreaStyle;
export declare function gridArea(rowStart: GridAreaInput, columnStart: GridAreaInput, rowEnd: GridAreaInput): GridAreaStyle;
export declare function gridArea(rowStart: GridAreaInput, columnStart: GridAreaInput, rowEnd: GridAreaInput, columnEnd: GridAreaInput): GridAreaStyle;
export {};
