import type { GriffelStyle } from '@griffel/style-types';
import type { TransitionDelayInput, TransitionDurationInput, TransitionPropertyInput, TransitionTimingFunctionInput, TransitionGlobalInput } from './types';
type TransitionInputs = [
    TransitionPropertyInput,
    TransitionDurationInput?,
    TransitionDelayInput?,
    TransitionTimingFunctionInput?
];
type TransitionStyle = Pick<GriffelStyle, 'transitionProperty' | 'transitionDelay' | 'transitionDuration' | 'transitionTimingFunction'>;
export declare function transition(globalValue: TransitionGlobalInput): TransitionStyle;
export declare function transition(property: TransitionPropertyInput, duration: TransitionDurationInput): TransitionStyle;
export declare function transition(property: TransitionPropertyInput, duration: TransitionDurationInput, delay: TransitionDelayInput): TransitionStyle;
export declare function transition(property: TransitionPropertyInput, duration: TransitionDurationInput, delay: TransitionDelayInput, easingFunction: TransitionTimingFunctionInput): TransitionStyle;
export declare function transition(values: TransitionInputs[]): TransitionStyle;
export {};
