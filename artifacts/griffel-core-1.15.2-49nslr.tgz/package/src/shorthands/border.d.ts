import type { GriffelStyle } from '@griffel/style-types';
import type { BorderColorInput, BorderStyleInput, BorderWidthInput } from './types';
type BorderStyle = Pick<GriffelStyle, 'borderTopColor' | 'borderTopStyle' | 'borderTopWidth' | 'borderRightColor' | 'borderRightStyle' | 'borderRightWidth' | 'borderBottomColor' | 'borderBottomStyle' | 'borderBottomWidth' | 'borderLeftColor' | 'borderLeftStyle' | 'borderLeftWidth'> | Pick<GriffelStyle, 'border'>;
export declare function border(width: BorderWidthInput): BorderStyle;
export declare function border(width: BorderWidthInput, style: BorderStyleInput): BorderStyle;
export declare function border(width: BorderWidthInput, style: BorderStyleInput, color: BorderColorInput): BorderStyle;
export {};
