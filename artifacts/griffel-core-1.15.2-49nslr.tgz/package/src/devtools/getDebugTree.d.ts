import type { SequenceHash } from '../types';
import type { DebugSequence } from './types';
export declare function getDebugTree(debugSequenceHash: SequenceHash, parentNode?: DebugSequence): DebugSequence | undefined;
