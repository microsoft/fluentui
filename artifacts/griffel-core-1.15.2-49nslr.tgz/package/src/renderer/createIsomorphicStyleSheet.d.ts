import type { IsomorphicStyleSheet, StyleBucketName } from '../types';
export declare function createIsomorphicStyleSheet(styleElement: HTMLStyleElement | undefined, bucketName: StyleBucketName, elementAttributes: Record<string, string>, priority?: number): IsomorphicStyleSheet;
export declare function createIsomorphicStyleSheetFromElement(element: HTMLStyleElement): IsomorphicStyleSheet;
