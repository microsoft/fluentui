import type { MakeResetStylesOptions } from './makeResetStyles';
/**
 * @internal
 */
export declare function __resetCSS(ltrClassName: string, rtlClassName: string | null): (options: Pick<MakeResetStylesOptions, 'dir'>) => string;
