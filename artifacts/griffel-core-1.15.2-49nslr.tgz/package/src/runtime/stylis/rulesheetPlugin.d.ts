import type { Element, Middleware } from 'stylis';
export type RulesheetPluginCallback = (type: Element, rule: string) => void;
/**
 * The same plugin as in stylis, but this version also has "element" argument.
 */
export declare function rulesheetPlugin(callback: RulesheetPluginCallback): Middleware;
