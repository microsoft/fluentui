import type { GriffelResetStyle } from '@griffel/style-types';
import type { CSSRulesByBucket } from '../types';
/**
 * @internal
 */
export declare function resolveResetStyleRules(styles: GriffelResetStyle): [string, string | null, CSSRulesByBucket | string[]];
