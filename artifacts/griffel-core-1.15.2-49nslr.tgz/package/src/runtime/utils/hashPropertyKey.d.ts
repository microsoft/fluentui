import type { PropertyHash } from '../../types';
export declare function hashPropertyKey(selector: string, container: string, media: string, support: string, property: string): PropertyHash;
