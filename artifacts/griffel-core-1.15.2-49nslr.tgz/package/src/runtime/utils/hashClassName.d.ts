interface HashedClassNameParts {
    property: string;
    value: string;
    selector: string;
    media: string;
    layer: string;
    support: string;
    container: string;
}
export declare function hashClassName({ container, media, layer, property, selector, support, value, }: HashedClassNameParts): string;
export {};
