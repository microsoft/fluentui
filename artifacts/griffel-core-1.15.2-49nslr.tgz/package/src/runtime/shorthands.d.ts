import type * as CSS from 'csstype';
export declare const shorthands: Partial<Record<keyof CSS.StandardShorthandProperties, [number, string[]]>>;
