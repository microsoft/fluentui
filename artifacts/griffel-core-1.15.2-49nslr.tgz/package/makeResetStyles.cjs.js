'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var constants = require('./constants.cjs.js');
var insertionFactory = require('./insertionFactory.cjs.js');
var resolveResetStyleRules = require('./runtime/resolveResetStyleRules.cjs.js');

function makeResetStyles(styles, factory = insertionFactory.insertionFactory) {
  const insertStyles = factory();
  let ltrClassName = null;
  let rtlClassName = null;
  let cssRules = null;
  function computeClassName(options) {
    const {
      dir,
      renderer
    } = options;
    if (ltrClassName === null) {
      [ltrClassName, rtlClassName, cssRules] = resolveResetStyleRules.resolveResetStyleRules(styles);
    }
    insertStyles(renderer, Array.isArray(cssRules) ? {
      r: cssRules
    } : cssRules);
    const className = dir === 'ltr' ? ltrClassName : rtlClassName || ltrClassName;
    if (process.env.NODE_ENV !== 'production') {
      constants.DEBUG_RESET_CLASSES[className] = 1;
    }
    return className;
  }
  return computeClassName;
}

exports.makeResetStyles = makeResetStyles;
//# sourceMappingURL=makeResetStyles.cjs.js.map
