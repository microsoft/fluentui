'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

/**
 * A function that implements CSS spec conformant expansion for "margin-inline"
 *
 * @example
 *   marginInline('10px')
 *   marginInline('10px', '5px')
 *
 * See https://developer.mozilla.org/en-US/docs/Web/CSS/margin-inline
 */
function marginInline(start, end = start) {
  return {
    marginInlineStart: start,
    marginInlineEnd: end
  };
}

exports.marginInline = marginInline;
//# sourceMappingURL=marginInline.cjs.js.map
