import { borderWidth } from './borderWidth.esm.js';
import { borderStyle } from './borderStyle.esm.js';
import { borderColor } from './borderColor.esm.js';
import { isBorderStyle } from './utils.esm.js';

/**
 * A function that implements expansion for "border" to all sides of an element, it's simplified - check usage examples.
 *
 * @deprecated Just use the "border" property directly, TODO link
 *
 * @example
 *  border('2px')
 *  border('solid')
 *  border('2px', 'solid')
 *  border('solid', '2px')
 *  border('2px', 'solid', 'red')
 *  border('solid', '2px', 'red')
 *
 * See https://developer.mozilla.org/en-US/docs/Web/CSS/border
 */
function border(...values) {
  if (values.some(value => Array.isArray(value))) {
    if (isBorderStyle(values[0])) {
      return Object.assign({}, borderStyle(values[0]), values[1] && borderWidth(values[1]), values[2] && borderColor(values[2]));
    }
    return Object.assign({}, borderWidth(values[0]), values[1] && borderStyle(values[1]), values[2] && borderColor(values[2]));
  }
  return {
    border: `${values[0]}${values[1] ? ` ${values[1]}` : ''}${values[2] ? ` ${values[2]}` : ''}`
  };
}

export { border };
//# sourceMappingURL=border.esm.js.map
