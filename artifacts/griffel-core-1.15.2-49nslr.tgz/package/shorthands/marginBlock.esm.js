/**
 * A function that implements CSS spec conformant expansion for "margin-block"
 *
 * @deprecated Use the "marginBlock" property directly, TODO link
 *
 * @example
 *   marginBlock('10px')
 *   marginBlock('10px', '5px')
 *
 * See https://developer.mozilla.org/en-US/docs/Web/CSS/margin-block
 */
function marginBlock(start, end = start) {
  if (Array.isArray(start) || Array.isArray(end)) {
    return {
      marginBlockStart: start,
      marginBlockEnd: end
    };
  }
  if (start === end) {
    return {
      marginBlock: start
    };
  }
  return {
    marginBlock: `${start} ${end}`
  };
}

export { marginBlock };
//# sourceMappingURL=marginBlock.esm.js.map
