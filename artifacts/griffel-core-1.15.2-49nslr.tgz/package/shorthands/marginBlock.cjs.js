'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

/**
 * A function that implements CSS spec conformant expansion for "margin-block"
 *
 * @deprecated Use the "marginBlock" property directly, TODO link
 *
 * @example
 *   marginBlock('10px')
 *   marginBlock('10px', '5px')
 *
 * See https://developer.mozilla.org/en-US/docs/Web/CSS/margin-block
 */
function marginBlock(start, end = start) {
  if (Array.isArray(start) || Array.isArray(end)) {
    return {
      marginBlockStart: start,
      marginBlockEnd: end
    };
  }
  if (start === end) {
    return {
      marginBlock: start
    };
  }
  return {
    marginBlock: `${start} ${end}`
  };
}

exports.marginBlock = marginBlock;
//# sourceMappingURL=marginBlock.cjs.js.map
