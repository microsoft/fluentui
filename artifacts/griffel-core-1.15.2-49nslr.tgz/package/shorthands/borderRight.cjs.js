'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var utils = require('./utils.cjs.js');

/**
 * A function that implements expansion for "border-right", it's simplified - check usage examples.
 *
 * @deprecated Use the "borderRight" property directly, TODO link
 *
 * @example
 *  borderRight('2px')
 *  borderRight('solid')
 *  borderRight('2px', 'solid')
 *  borderRight('solid', '2px')
 *  borderRight('2px', 'solid', 'red')
 *  borderRight('solid', '2px', 'red')
 *
 * See https://developer.mozilla.org/en-US/docs/Web/CSS/border-right
 */
function borderRight(...values) {
  if (values.some(value => Array.isArray(value))) {
    if (utils.isBorderStyle(values[0])) {
      return Object.assign({
        borderRightStyle: values[0]
      }, values[1] && {
        borderRightWidth: values[1]
      }, values[2] && {
        borderRightColor: values[2]
      });
    }
    return Object.assign({
      borderRightWidth: values[0]
    }, values[1] && {
      borderRightStyle: values[1]
    }, values[2] && {
      borderRightColor: values[2]
    });
  }
  return {
    borderRight: values.join(' ')
  };
}

exports.borderRight = borderRight;
//# sourceMappingURL=borderRight.cjs.js.map
