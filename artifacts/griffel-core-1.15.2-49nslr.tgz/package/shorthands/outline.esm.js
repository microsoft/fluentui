/**
 * A function that implements expansion for "outline", it's simplified - check usage examples.
 *
 * @deprecated Use the "outline" property directly, TODO link
 *
 * @example
 *  outline('2px')
 *  outline('2px', 'solid')
 *  outline('2px', 'solid', 'red')
 *
 * See https://developer.mozilla.org/en-US/docs/Web/CSS/outline
 *
 */
function outline(outlineWidth, outlineStyle, outlineColor) {
  if (Array.isArray(outlineWidth) || Array.isArray(outlineStyle) || Array.isArray(outlineColor)) {
    return Object.assign({
      outlineWidth
    }, outlineStyle && {
      outlineStyle
    }, outlineColor && {
      outlineColor
    });
  }
  return {
    outline: `${outlineWidth}${outlineStyle ? ` ${outlineStyle}` : ''}${outlineColor ? ` ${outlineColor}` : ''}`
  };
}

export { outline };
//# sourceMappingURL=outline.esm.js.map
