/**
 * A function that implements CSS spec conformant expansion for "overflow"
 *
 * @deprecated Use the "overflow" property directly, TODO link
 *
 * @example
 *   overflow('hidden')
 *   overflow('hidden', 'scroll')
 *
 * See https://developer.mozilla.org/en-US/docs/Web/CSS/overflow
 */
function overflow(overflowX, overflowY = overflowX) {
  if (Array.isArray(overflowX) || Array.isArray(overflowY)) {
    return {
      overflowX,
      overflowY
    };
  }
  if (overflowX === overflowY) {
    return {
      overflow: overflowX
    };
  }
  return {
    overflow: `${overflowX} ${overflowY}`
  };
}

export { overflow };
//# sourceMappingURL=overflow.esm.js.map
