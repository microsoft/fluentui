const positionMap = ['Top', 'Right', 'Bottom', 'Left'];
function generateStyles(property, suffix, ...values) {
  const [firstValue, secondValue = firstValue, thirdValue = firstValue, fourthValue = secondValue] = values;
  const valuesWithDefaults = [firstValue, secondValue, thirdValue, fourthValue];
  if (values.some(value => Array.isArray(value))) {
    const styles = {};
    for (let i = 0; i < valuesWithDefaults.length; i += 1) {
      if (valuesWithDefaults[i] || valuesWithDefaults[i] === 0) {
        const newKey = property + positionMap[i] + suffix;
        styles[newKey] = valuesWithDefaults[i];
      }
    }
    return styles;
  }
  if (firstValue === secondValue && firstValue === thirdValue && firstValue === fourthValue) {
    return {
      [property + suffix]: firstValue
    };
  }
  if (firstValue === thirdValue && secondValue === fourthValue) {
    return {
      [property + suffix]: `${firstValue} ${secondValue}`
    };
  }
  if (secondValue === fourthValue) {
    return {
      [property + suffix]: `${firstValue} ${secondValue} ${thirdValue}`
    };
  }
  return {
    [property + suffix]: `${firstValue} ${secondValue} ${thirdValue} ${fourthValue}`
  };
}

export { generateStyles };
//# sourceMappingURL=generateStyles.esm.js.map
