'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

/**
 * A function that implements CSS spec conformant expansion for "gap"
 *
 * @deprecated Just use the "gap" property directly, TODO link
 *
 * @example
 *   gap('10px')
 *   gap('10px', '5px')
 *
 * See https://developer.mozilla.org/en-US/docs/Web/CSS/gap
 */
function gap(columnGap, rowGap = columnGap) {
  if (Array.isArray(columnGap) || Array.isArray(rowGap)) {
    return {
      columnGap,
      rowGap
    };
  }
  if (columnGap === rowGap) {
    return {
      gap: columnGap
    };
  }
  return {
    gap: `${columnGap} ${rowGap}`
  };
}

exports.gap = gap;
//# sourceMappingURL=gap.cjs.js.map
