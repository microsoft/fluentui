'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var utils = require('./utils.cjs.js');

/**
 * A function that implements expansion for "border-left", it's simplified - check usage examples.
 *
 * @deprecated Use the "borderLeft" property directly, TODO link
 *
 * @example
 *  borderLeft('2px')
 *  borderLeft('solid')
 *  borderLeft('2px', 'solid')
 *  borderLeft('solid', '2px')
 *  borderLeft('2px', 'solid', 'red')
 *  borderLeft('solid', '2px', 'red')
 *
 * See https://developer.mozilla.org/en-US/docs/Web/CSS/border-left
 */
function borderLeft(...values) {
  if (values.some(value => Array.isArray(value))) {
    if (utils.isBorderStyle(values[0])) {
      return Object.assign({
        borderLeftStyle: values[0]
      }, values[1] && {
        borderLeftWidth: values[1]
      }, values[2] && {
        borderLeftColor: values[2]
      });
    }
    return Object.assign({
      borderLeftWidth: values[0]
    }, values[1] && {
      borderLeftStyle: values[1]
    }, values[2] && {
      borderLeftColor: values[2]
    });
  }
  return {
    borderLeft: values.join(' ')
  };
}

exports.borderLeft = borderLeft;
//# sourceMappingURL=borderLeft.cjs.js.map
