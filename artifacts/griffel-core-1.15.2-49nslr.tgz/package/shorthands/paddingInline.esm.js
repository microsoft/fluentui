/**
 * A function that implements CSS spec conformant expansion for "padding-inline"
 *
 * @deprecated Just use the "paddingInline" property directly, TODO link
 *
 * @example
 *   paddingInline('10px')
 *   paddingInline('10px', '5px')
 *
 * See https://developer.mozilla.org/en-US/docs/Web/CSS/padding-inline
 */
function paddingInline(start, end = start) {
  if (Array.isArray(start) || Array.isArray(end)) {
    return {
      paddingInlineStart: start,
      paddingInlineEnd: end
    };
  }
  if (start === end) {
    return {
      paddingInline: start
    };
  }
  return {
    paddingInline: `${start} ${end}`
  };
}

export { paddingInline };
//# sourceMappingURL=paddingInline.esm.js.map
