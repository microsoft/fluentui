import { __resetCSS as __resetCSS$1 } from '@griffel/core';
import { useTextDirection } from './TextDirectionContext.esm.js';

/**
 * A version of makeResetStyles() that accepts build output as an input and skips all runtime transforms & DOM insertion.
 *
 * @internal
 */
// eslint-disable-next-line @typescript-eslint/naming-convention
function __resetCSS(ltrClassName, rtlClassName) {
  const getStyles = __resetCSS$1(ltrClassName, rtlClassName);
  return function useClasses() {
    const dir = useTextDirection();
    return getStyles({
      dir
    });
  };
}

export { __resetCSS };
//# sourceMappingURL=__resetCSS.esm.js.map
