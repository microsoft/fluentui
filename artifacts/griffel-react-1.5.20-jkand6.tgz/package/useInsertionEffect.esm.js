import * as React from 'react';

const useInsertionEffect =
// @ts-expect-error Hack to make sure that `useInsertionEffect` will not cause bundling issues in older React versions
// eslint-disable-next-line no-useless-concat
React['useInsertion' + 'Effect'] ? React['useInsertion' + 'Effect'] : undefined;

export { useInsertionEffect };
//# sourceMappingURL=useInsertionEffect.esm.js.map
