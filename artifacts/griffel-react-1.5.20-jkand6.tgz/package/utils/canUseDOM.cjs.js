'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

/**
 * Verifies if an application can use DOM.
 */
function canUseDOM() {
  return typeof window !== 'undefined' && !!(window.document && window.document.createElement);
}

exports.canUseDOM = canUseDOM;
//# sourceMappingURL=canUseDOM.cjs.js.map
