import type { NodePath, PluginObj, PluginPass } from '@babel/core';
import { types as t } from '@babel/core';
import type { BabelPluginOptions, BabelPluginMetadata } from './types';
type FunctionKinds = 'makeStyles' | 'makeResetStyles';
type BabelPluginState = PluginPass & {
    importDeclarationPaths?: NodePath<t.ImportDeclaration>[];
    requireDeclarationPath?: NodePath<t.VariableDeclarator>;
    definitionPaths?: {
        /** The name of the resulting hook from a Griffel call */
        declaratorId: string;
        /** The type of Griffel call */
        functionKind: FunctionKinds;
        /** The code path of the Griffel call  */
        path: NodePath<t.Expression | t.SpreadElement>;
    }[];
    calleePaths?: NodePath<t.Identifier>[];
    cssEntries?: BabelPluginMetadata['cssEntries'];
    cssResetEntries?: BabelPluginMetadata['cssResetEntries'];
};
export declare const transformPlugin: (api: object, options: Partial<BabelPluginOptions> | null | undefined, dirname: string) => PluginObj<BabelPluginState>;
export {};
