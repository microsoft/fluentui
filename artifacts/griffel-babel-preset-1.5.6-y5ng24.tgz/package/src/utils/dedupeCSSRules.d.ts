import type { CSSRulesByBucket } from '@griffel/core';
/**
 * Rules that are returned by `resolveStyles()` are not deduplicated.
 * It's critical to filter out duplicates for build-time transform to avoid duplicated rules in a bundle.
 */
export declare function dedupeCSSRules(cssRulesByBucket: CSSRulesByBucket): CSSRulesByBucket;
