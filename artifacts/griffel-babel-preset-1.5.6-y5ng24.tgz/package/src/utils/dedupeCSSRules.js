"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dedupeCSSRules = void 0;
/**
 * Rules that are returned by `resolveStyles()` are not deduplicated.
 * It's critical to filter out duplicates for build-time transform to avoid duplicated rules in a bundle.
 */
function dedupeCSSRules(cssRulesByBucket) {
    return Object.fromEntries(Object.entries(cssRulesByBucket).map(([styleBucketName, cssBucketEntries]) => {
        if (styleBucketName === 'm') {
            return [
                styleBucketName,
                cssBucketEntries.filter((entryA, index, entries) => entries.findIndex(entryB => entryA[0] === entryB[0]) === index),
            ];
        }
        return [styleBucketName, [...new Set(cssBucketEntries)]];
    }));
}
exports.dedupeCSSRules = dedupeCSSRules;
//# sourceMappingURL=dedupeCSSRules.js.map