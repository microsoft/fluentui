"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isAssetUrl = void 0;
function isAssetUrl(value) {
    const url = value.replace(/^['|"]/, '');
    const isRemoteUrl = url.startsWith('data:') ||
        url.startsWith('http:') ||
        url.startsWith('https:') ||
        url.startsWith('//') /* Urls without protocol (use the same protocol as current page) */ ||
        url.startsWith('#');
    return !isRemoteUrl;
}
exports.isAssetUrl = isAssetUrl;
//# sourceMappingURL=isAssetUrl.js.map